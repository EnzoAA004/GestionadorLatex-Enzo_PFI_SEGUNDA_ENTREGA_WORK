# H04 — auditoría sagital Dice/IoU por clase

**Resultado:** NO_RECALCULADO: hacen falta reporte original por clase o arrays de test vinculadas al checkpoint

## Proveniencia esperada
- Checkpoint SHA-256: `cf11dcc0ad77a7c787e64a796a2fd7398ef906add461cef4b3d61f1a5238e944`
- Índice de entrenamiento SHA-256: `2720b7218c92870f6f0a000b57111ed36b5cf3b78c716f244f427ca7fee4a4ba`
- Test propio declarado: 33 pacientes, 1.218 cortes.
- Dice macro test no-background original: 0,8934316063846954.
- IoU macro test no-background original: 0,8079981902423006.

## Cobertura y control
- Pareamiento: no_configurado
- Hash checkpoint: no_proporcionado
- Hash índice: no_proporcionado
- Reportes JSON relevantes revisados: 23


## Límites
- Métricas históricas no se modifican sin verificación del procedimiento fuente.
- No implica evaluación clínica ni externa.
- No publicar identificadores o arrays clínicos en GitHub.
