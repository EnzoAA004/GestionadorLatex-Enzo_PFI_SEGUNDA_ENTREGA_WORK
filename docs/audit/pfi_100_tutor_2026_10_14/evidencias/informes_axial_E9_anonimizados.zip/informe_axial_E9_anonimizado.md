# Informe read-only de partición axial E9 · hallazgo 11

- SHA-256 contra manifest V2: **COINCIDE**
- Registros: **610** (esperados 610; coinciden)
- Registros por split: train **427**, val **81**, test **102**
- Pacientes únicos por split: train **128**, val **27**, test **29**
- Filas duplicadas: **0**
- Cruces por paciente: **0** (por pares de splits)
- Cruces por estudio: **0** (por pares de splits)
- Cruces por ruta de imagen: **0** (por pares de splits)
- Cruces por ruta de máscara: **0** (por pares de splits)

## Interpretación
Los controles descriptivos del CSV pasan. Esto NO rehabilita la independencia histórica del test.

## Restricciones
- El hash demuestra identidad del CSV, no una validación clínica ni test externo nuevo.
- Los 610 elementos son registros/imágenes curadas; no se equiparan a pacientes.
- El test se había utilizado previamente en axial-full-v1: sigue sin ser evaluación independiente completamente nueva.
- Sin hash de los archivos de imagen no se descarta que existan duplicados de contenido con nombres distintos.
- La semántica médica de etiquetas raw_* no se verifica en este notebook.
